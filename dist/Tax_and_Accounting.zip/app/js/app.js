// --- Zoho CRM Widget Logic ---

let account_id, app_id;
let cachedFile = null;
let cachedBase64 = null;

/**
 * Initializes the embedded app on Zoho CRM PageLoad event.
 * Fetches current Application and Account IDs for record updates.
 */
ZOHO.embeddedApp.on("PageLoad", async (entity) => {
    try {
        const entity_id = entity.EntityId;

        // 1. Get Application record data
        const appResponse = await ZOHO.CRM.API.getRecord({
            Entity: "Applications1",
            approved: "both",
            RecordID: entity_id,
        });

        const applicationData = appResponse.data[0];
        app_id = applicationData.id;
        // Safely extract account_id
        account_id = applicationData.Account_Name ? applicationData.Account_Name.id : null;

        // 2. Resize the widget UI
        ZOHO.CRM.UI.Resize({ height: "90%" }).then(function (data) {
            console.log("Resize result:", data);
        });
    } catch (error) {
        console.error("PageLoad error:", error);
    }
});

/** Clears all validation error messages on the form. */
function clearErrors() {
    document.querySelectorAll(".error-message").forEach(span => {
        span.textContent = "";
    });
}

/**
 * Displays a validation error message for a specific form field.
 * @param {string} fieldId - The ID of the form field's error span.
 * @param {string} message - The error message to display.
 */
function showError(fieldId, message) {
    const errorSpan = document.getElementById(`error-${fieldId}`);
    if (errorSpan) errorSpan.textContent = message;
}

/** Shows the indeterminate file upload progress buffer overlay. */
function showUploadBuffer() {
    const buffer = document.getElementById("upload-buffer");
    const bar = document.getElementById("upload-progress");
    if (buffer) buffer.classList.remove("hidden");
    // Rerun animation by removing and re-adding the class
    if (bar) {
        bar.classList.remove("animate");
        void bar.offsetWidth; // Force reflow
        bar.classList.add("animate");
    }
}

/** Hides the indeterminate file upload progress buffer overlay. */
function hideUploadBuffer() {
    const buffer = document.getElementById("upload-buffer");
    if (buffer) buffer.classList.add("hidden");
}

/**
 * Handles file selection, performs validation, and caches the file content as Base64.
 * @param {Event} event - The file input change event.
 */
async function cacheFileOnChange(event) {
    clearErrors();

    const fileInput = event.target;
    const file = fileInput?.files[0];

    if (!file) return;

    // File size validation (Max 20MB)
    const MAX_FILE_SIZE = 20 * 1024 * 1024;
    if (file.size > MAX_FILE_SIZE) {
        showError("corporate-tax-certificate", "File size must not exceed 20MB.");
        fileInput.value = ""; // Clear the input field
        return;
    }

    showUploadBuffer();

    try {
        const base64 = await new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                // Extract only the Base64 content
                const result = reader.result.split(',')[1];
                resolve(result);
            };
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });

        cachedFile = file;
        cachedBase64 = base64;

        // Simulate a slight delay for better UX
        await new Promise((res) => setTimeout(res, 1500));
        hideUploadBuffer();
    } catch (err) {
        console.error("Error caching file:", err);
        hideUploadBuffer();
        showError("corporate-tax-certificate", "Failed to read file.");
        fileInput.value = ""; // Clear the input field
    }
}

/**
 * Uploads the cached file to the Zoho CRM record as an attachment.
 * @returns {Promise<Object>} - The Zoho API response.
 */
async function uploadFileToCRM() {
    if (!cachedFile || !cachedBase64) {
        // This case should be caught by update_record validation, but kept for safety.
        throw new Error("No cached file for upload.");
    }

    console.log("Attaching file to record...");
    return await ZOHO.CRM.API.attachFile({
        Entity: "Applications1",
        RecordID: app_id,
        File: {
            Name: cachedFile.name,
            Content: cachedBase64,
        },
    });
}

/** Placeholder trigger - the actual proceed is in update_record */
function complete_trigger() {
    // This is actually not needed anymore, as update_record handles the whole flow.
    // ZOHO.CRM.BLUEPRINT.proceed();
}

/**
 * Main function to gather data, validate, update CRM records, and finalize the blueprint.
 * @param {Event} event - The form submission event.
 */
async function update_record(event = null) {
    // CRITICAL FIX: Stop the default form submission (browser reload)
    if (event) event.preventDefault();

    clearErrors();

    let hasError = false;

    const submitBtn = document.getElementById("submit_button_id");
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = "Submitting...";
    }

    // --- Data Retrieval ---
    const effectiveDate = document.getElementById("effective-date")?.value;
    const dateOfIssue = document.getElementById("date-of-issue")?.value;
    const ctrDueDate = document.getElementById("ctr-due-date")?.value;
    const taxRegNo = document.getElementById("tax-registration-number")?.value;
    const taxPeriodCt = document.getElementById("tax-period-ct")?.value;
    const ctrFinancialYearEnd = document.getElementById("ctr-financial-year-end-date")?.value;

    // --- Validation ---
    if (!taxRegNo) {
        showError("tax-registration-number", "Tax Registration Number is required.");
        hasError = true;
    }

    if (!taxPeriodCt) {
        showError("tax-period-ct", "Tax Period is required.");
        hasError = true;
    }

    if (!ctrFinancialYearEnd) {
        showError("ctr-financial-year-end-date", "CTR Financial Year End Date is required.");
        hasError = true;
    }

    if (!effectiveDate) {
        showError("effective-date", "Effective Registration Date is required.");
        hasError = true;
    }

    if (!dateOfIssue) {
        showError("date-of-issue", "Date of Issue is required.");
        hasError = true;
    }

    if (!ctrDueDate) {
        showError("ctr-due-date", "CTR Due Date is required.");
        hasError = true;
    }

    if (!cachedFile || !cachedBase64) {
        showError("corporate-tax-certificate", "Please upload the Corporate Tax Certificate.");
        hasError = true;
    }

    // --- Error Halt ---
    if (hasError) {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = "Submit";
        }
        return; // Stop execution if validation fails
    }

    // --- API Submission ---
    try {
        const subformData = [];

        if (dateOfIssue) {
            subformData.push({ Type_of_Dates: "Date of Issue", Date: dateOfIssue });
        }

        if (effectiveDate) {
            subformData.push({ Type_of_Dates: "Effective Date of Registration", Date: effectiveDate });
        }

        if (ctrDueDate) {
            subformData.push({ Type_of_Dates: "CTR Due Date", Date: ctrDueDate });
        }

        if (ctrFinancialYearEnd) {
            subformData.push({ Type_of_Dates: "CTR Financial Year End Date", Date: ctrFinancialYearEnd });
        }

        // 1. Update Application Record
        await ZOHO.CRM.API.updateRecord({
            Entity: "Applications1",
            APIData: {
                id: app_id,
                Tax_Registration_Number_TRN: taxRegNo,
                Tax_Period_CT: taxPeriodCt,
                Subform_2: subformData,
                Application_Issuance_Date: dateOfIssue
            }
        });

        // 2. Update Account Record
        await ZOHO.CRM.API.updateRecord({
            Entity: "Accounts",
            APIData: {
                id: account_id,
                Effective_Registration_Date_CT: effectiveDate,
                CT_Return_DD: ctrDueDate,
                Tax_Period_CT: taxPeriodCt,
                Corporate_Tax_TRN: taxRegNo,
                CT_Status: "Active"
            }
        });

        // 3. Upload File
        await uploadFileToCRM();

        // 4. Proceed Blueprint and Close Widget (Only runs on successful updates)
        await ZOHO.CRM.BLUEPRINT.proceed();
        await ZOHO.CRM.UI.Popup.closeReload();

    } catch (error) {
        console.error("Error on final submit:", error);
        // Re-enable button on API failure
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = "Submit";
        }
        // Optionally show a general error message to the user here
    }
}

/**
 * Auto-populates the Financial Year End Date based on the CTR Due Date
 * (subtracts 9 months and gets the last day of that month).
 */
function autoPopulateFinancialYearEndDate() {
    const ctrDueDateInput = document.getElementById("ctr-due-date");
    const financialYearEndInput = document.getElementById("ctr-financial-year-end-date");

    // Event listener for when CTR Due Date changes
    ctrDueDateInput.addEventListener("change", () => {
        const dueDateValue = ctrDueDateInput.value;
        if (!dueDateValue) {
            financialYearEndInput.value = "";
            return;
        }

        const dueDate = new Date(dueDateValue);
        // The due date is 9 months after the financial year end date.
        // To find the financial year end date, subtract 9 months from the due date.
        // Month indices are 0-based.
        const targetMonth = dueDate.getMonth() - 9;
        const targetYear = dueDate.getFullYear();

        // Create a date object for the 1st of the target month
        const adjustedDate = new Date(targetYear, targetMonth, 1);

        // Get the last day of the adjusted month (by setting day 0 of the *next* month)
        const lastDay = new Date(adjustedDate.getFullYear(), adjustedDate.getMonth() + 1, 0);

        const yyyy = lastDay.getFullYear();
        const mm = String(lastDay.getMonth() + 1).padStart(2, '0');
        const dd = String(lastDay.getDate()).padStart(2, '0');

        financialYearEndInput.value = `${yyyy}-${mm}-${dd}`;
    });
}

/** Closes the embedded widget and reloads the parent CRM page. */
async function closeWidget() {
    await ZOHO.CRM.UI.Popup.closeReload().then(console.log);
}

// --- Event Listeners and Initialization ---

// Listener setup needs to wait until the DOM is loaded.
// Since the script is included right before </body>, the DOM should be ready.

// Listen for file change event to cache the file
document.getElementById("corporate-tax-certificate").addEventListener("change", cacheFileOnChange);

// Listen for form submission event to trigger validation and update
document.getElementById("record-form").addEventListener("submit", update_record);

// Initialize auto-population logic
autoPopulateFinancialYearEndDate();

// Initialize the embedded app
ZOHO.embeddedApp.init();

// End of Zoho CRM Widget Logic